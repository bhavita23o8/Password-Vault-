import hashlib
from database import init_db, get_db_connection

# Initialize DB tables
init_db()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def is_first_time():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM master")
    result = cursor.fetchone()[0]
    conn.close()
    return result == 0

def set_master_password(password):
    hashed = hash_password(password)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO master (password) VALUES (%s)", (hashed,))

    conn.commit()
    conn.close()

def verify_master_password(password):
    hashed = hash_password(password)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT password FROM master LIMIT 1")
    result = cursor.fetchone()
    conn.close()
    if result:
        return hashed == result[0]
    return False
