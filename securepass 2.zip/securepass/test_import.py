from encryption_util import encrypt, decrypt

print(encrypt)
print(decrypt)
