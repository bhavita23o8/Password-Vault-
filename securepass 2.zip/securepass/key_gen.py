# key_gen.py
from cryptography.fernet import Fernet
import os

KEY_FILE = "data/key.key"

def generate_key():
    # Create data directory if it doesn't exist
    os.makedirs(os.path.dirname(KEY_FILE), exist_ok=True)
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as key_file:
        key_file.write(key)
    print(f"Key generated and saved to {KEY_FILE}")

if __name__ == "__main__":
    generate_key()
