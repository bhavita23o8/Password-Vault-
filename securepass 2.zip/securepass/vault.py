from encryption_util import encrypt, decrypt
from database import get_db_connection

def add_credential(website, username, password):
    encrypted_password = encrypt(password)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO credentials (website, username, password)
    VALUES (%s, %s, %s)
""", (website, username, encrypted_password))
    conn.commit()
    conn.close()

def get_credentials():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT website, username, password FROM credentials")
    rows = cursor.fetchall()
    conn.close()

    credentials = []
    for website, username, encrypted_password in rows:
        try:
            decrypted_password = decrypt(encrypted_password)
            credentials.append({
                'website': website,
                'username': username,
                'password': decrypted_password
            })
        except Exception as e:
            # skip entry if decryption fails
            continue
    return credentials

def delete_credential(website):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM credentials WHERE website = %s", (website,))
    conn.commit()
    affected = cursor.rowcount
    conn.close()
    return affected > 0
