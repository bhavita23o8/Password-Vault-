import re
import requests

# Your existing phishing keywords for quick checks
PHISHING_KEYWORDS = [
    "free-login", "bonus", "offer", "secure-update", "verify-now",
    "bank-alert", "account-locked", "login-reset"
]

def is_phishing_url_basic(url: str) -> bool:
    """Basic pattern-based phishing check"""
    for keyword in PHISHING_KEYWORDS:
        if keyword in url.lower():
            return True

    if re.search(r"(login|secure|update)[0-9]*\.(com\.ru|xyz|top|tk|ml|ga|cf)", url):
        return True

    if url.count("-") > 3 or url.count(".") > 4:
        return True

    return False

def is_phishing_url_google(url: str, api_key: str) -> bool:
    """Check URL using Google Safe Browsing API"""
    endpoint = "https://safebrowsing.googleapis.com/v4/threatMatches:find"
    headers = {'Content-Type': 'application/json'}
    payload = {
        "client": {
            "clientId": "PasswordVault",
            "clientVersion": "1.0"
        },
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "POTENTIALLY_HARMFUL_APPLICATION"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}]
        }
    }

    try:
        response = requests.post(f"{endpoint}?key={api_key}", json=payload, headers=headers, timeout=5)
        response.raise_for_status()
        result = response.json()
        return "matches" in result  # True if any threats found
    except Exception as e:
        print(f"Google Safe Browsing API error: {e}")
        # Fail-safe: consider no phishing if API fails (or you can choose True to be stricter)
        return False

def is_phishing_url(url: str, api_key: str = None) -> bool:
    """Combined phishing URL check"""
    # First check with basic patterns
    if is_phishing_url_basic(url):
        return True

    # If API key provided, check with Google Safe Browsing API too
    if api_key and is_phishing_url_google(url, api_key):
        return True

    return False


