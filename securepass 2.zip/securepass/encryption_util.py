from cryptography.fernet import Fernet
import os

KEY_FILE = "data/key.key"

# Generate and save encryption key (once)
def generate_key():
    if not os.path.exists(KEY_FILE):
        key = Fernet.generate_key()
        os.makedirs("data", exist_ok=True)
        with open(KEY_FILE, "wb") as f:
            f.write(key)

# Load encryption key from file
def load_key():
    with open(KEY_FILE, "rb") as f:
        return f.read()

# Encrypt plain text
def encrypt(data: str) -> bytes:
    key = load_key()
    f = Fernet(key)
    return f.encrypt(data.encode())

# Decrypt encrypted text
def decrypt(token: bytes) -> str:
    key = load_key()
    f = Fernet(key)
    return f.decrypt(token).decode()
